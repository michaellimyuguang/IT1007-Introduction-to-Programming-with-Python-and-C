import matplotlib.pyplot as plt

def plot_birth_rate():
    with open('crude-birth-rate.csv') as f:
        f.readline()
        year = []
        num_birth = []
        for line in f:
            list_form = line.rstrip('\n').split(',')
            year.append(int(list_form[0]))
            num_birth.append(float(list_form[2])*1000)


    plt.plot(year,num_birth,label="Birth Rate")
    plt.legend(loc="upper right")
    plt.title('Number of births.')
    plt.show()
            
plot_birth_rate()
    
