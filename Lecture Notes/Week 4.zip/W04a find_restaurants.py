import random
from math import sqrt

NO_RESTAURANTS = 1000
SIZE_OF_SG = 300
DISTANCE_RANGE = 10

def generate_list():
    output_list = []
    for i in range(NO_RESTAURANTS):
        output_list.append( (random.randint(1,SIZE_OF_SG),
                             random.randint(1,SIZE_OF_SG)))
    return output_list

def distance(p1,p2):
    return sqrt( square(p1[0]-p2[0]) + square(p1[1]-p2[1]))

def square(x):
    return x * x

def find_restaurants(my_current_pos):
    locations = generate_list()
    output_list = []
    
    for loc in locations:
        if distance(my_current_pos, loc) < DISTANCE_RANGE:
            output_list.append(loc)

    return output_list


    
