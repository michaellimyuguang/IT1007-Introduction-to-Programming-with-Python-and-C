import numpy as np
import matplotlib.pyplot as plt
from Lab_02_Part_A_solution import nChooseK 


N = 18

x = [i for i in range(0,N+1)]
y = [nChooseK(N,i) for i in range(0,N+1)]

plt.bar(x,y)

plt.show()





