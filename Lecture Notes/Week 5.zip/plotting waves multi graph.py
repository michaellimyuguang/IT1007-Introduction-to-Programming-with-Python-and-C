import numpy as np
import matplotlib.pyplot as plt

# Create x, evenly spaced between 0 to 4 pi
x = np.linspace(0, 3.14 * 4 , 100)

y1 = np.sin(x)
y2 = np.cos(x)

# Plot the sin and cos functions
plt.subplot(211)
plt.plot(x , y1, "-g")
plt.title('Sine Curve')

plt.subplot(212)
plt.plot(x , y2, "--b")
plt.title('Cosine Curve')

# Limit the y axis to -1.5 to 1.5
plt.ylim(-1.5, 1.5)

plt.show()





