import numpy as np
import matplotlib.pyplot as plt

x1 = np.linspace(0,3.14,100)
y1 = np.cos(x1)

plt.plot(x1,y1)

plt.show()


