import matplotlib.pyplot as plt
import numpy as np
import csv

def plot_birth_rate():
    birth_file = open('crude-birth-rate.csv')
    birth_file_reader = csv.reader(birth_file)
    
    birth_data = np.array(list(birth_file_reader))
    year = birth_data[1:,0]
    num_birth = birth_data[1:,2]
    birth_file.close()

    plt.plot(year,num_birth,label="Birth Rate")
    plt.legend(loc="upper right")
    plt.title('Number of births.')
    plt.show()

    
plot_birth_rate()
    
