import matplotlib.pyplot as plt
 
labels = ['Python', 'Java','C++', 'C#', 'C','JavaScript','Ruby','Others']
sizes = [26.7,22.6,9.9,9.4,7.37,6.9,5.9,11.23]

plt.pie(sizes,shadow=True, startangle=90)
plt.legend(labels, loc="best")

plt.axis('equal')
plt.title('Programming Languages Used in 2016')
plt.tight_layout()
plt.show()


