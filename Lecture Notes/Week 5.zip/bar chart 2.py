import numpy as np
import matplotlib.pyplot as plt


n_groups = 5

means_men = (20, 35, 30, 35, 27)
std_men = (2, 3, 4, 1, 2)

means_women = (25, 32, 34, 20, 25)
std_women = (3, 5, 2, 3, 3)

index = (1,2,3,4,5)

rects1 = plt.bar(index, means_men, 
                 color='b',
                 yerr=std_men,
#                 error_kw=error_config,
                 label='Men')
'''
rects2 = plt.bar(index, means_women, 
                 color='r',
                 yerr=std_women,
#                 error_kw=error_config,
                 label='Women')
'''
plt.show()



