def p1(x):
    print('Entering function p1')
    output = p2(x)
    print('Line before return in p1')
    return output


def p2(x):
    print('Entering function p2')
    output = p3(x)
    print('Line before return in p2')
    return output

def p3(x):
    print('Entering function p3')
    output = x * x
    print('Line before return in p3')
    return output


print(p1(3))
