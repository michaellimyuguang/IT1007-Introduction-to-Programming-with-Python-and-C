POUNDS_IN_ONE_KG = 2.20462

def kg2pound(w):
    return w * POUNDS_IN_ONE_KG

def pound2kg(w):
    return w / POUNDS_IN_ONE_KG




    
