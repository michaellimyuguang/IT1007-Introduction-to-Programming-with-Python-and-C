def factorialR(n):
    if n == 1:
        return 1
    else:
        return n * factorialR(n-1)

