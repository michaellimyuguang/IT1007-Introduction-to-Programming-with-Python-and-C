x = 0

def foo_printx():
    global x
    x = 999
    print(x)

foo_printx()
print(x)
