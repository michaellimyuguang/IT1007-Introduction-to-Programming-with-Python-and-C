from my_cool_package import square as sq

def squared_sum(a,b):
    return sq(a) + sq(b)


print(squared_sum(3,4))


