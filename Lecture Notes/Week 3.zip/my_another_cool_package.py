import my_cool_package 
from math import pi

def circle_area_by_radius(r):
    return pi * my_cool_package.square(r)


print(circle_area_by_radius(10))


