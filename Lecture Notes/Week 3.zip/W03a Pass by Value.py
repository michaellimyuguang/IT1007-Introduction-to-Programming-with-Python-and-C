x = 0

def changeValue(n):
    n = 999
    print(n)

changeValue(x)
print(x)
